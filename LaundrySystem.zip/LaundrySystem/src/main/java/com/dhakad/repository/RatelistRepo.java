package com.dhakad.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.dhakad.entity.Category;
import com.dhakad.entity.Cloth;
import com.dhakad.entity.Ratelist;
import com.dhakad.entity.Status;
@Repository
public interface RatelistRepo extends JpaRepository<Ratelist, Integer> {

	
	@Modifying
	@Query("update Ratelist r set r.price=:price where r.id=:id")
	@Transactional
	public int updateRatelist(@Param("id") int custId,@Param("price") int price);
	
	
	//fetching price from ratelist where cloth=cloth and category=category
	@Query("select price from Ratelist as r where r.cloth=:cloth and r.category=:category ")
	public int getPriceByClothAndCategory(@Param("cloth")Cloth cloth,@Param("category")Category category);

	
	
	
	
	
	
	
	
	
	
	
	
	/*
	 * this query help to understanding how to fech data in one to many mapping 
	 * 
	 	@Query("from Order_Table as o where o.status=:status")
		public Order_Table getOrderByStatus(@Param("status") Status status);
	*/
}
