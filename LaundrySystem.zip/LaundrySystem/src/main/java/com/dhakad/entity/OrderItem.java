package com.dhakad.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "order_item")
public class OrderItem {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@Column(name = "category_name",nullable = false)
	private String categoryName;
	@Column(name = "cloth_name",nullable = false)
	private String clothName;
	@Column(name = "price",nullable = false)
	private int price;
	@Column(name = "quantity",nullable = false)
	private int quantity;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public String getClothName() {
		return clothName;
	}
	public void setClothName(String clothName) {
		this.clothName = clothName;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public OrderItem() {
		super();
		// TODO Auto-generated constructor stub
	}
	public OrderItem(int id, String categoryName, String clothName, int price, int quantity) {
		super();
		this.id = id;
		this.categoryName = categoryName;
		this.clothName = clothName;
		this.price = price;
		this.quantity = quantity;
	}
	public OrderItem(int id) {
		super();
		this.id = id;
	}
	@Override
	public String toString() {
		return "OrderItem [id=" + id + ", categoryName=" + categoryName + ", clothName=" + clothName + ", price="
				+ price + ", quantity=" + quantity + "]";
	}
	
	
	
}
