package com.dhakad.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "pickup")
public class PickUpTimeSlot {

	@Id
	@Column(name = "pickup_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int pickUpTimeId;
	
	@Column(name = "timeslot",nullable = false)
	private String timeSlot;
	
	
		
	public PickUpTimeSlot() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getPickUpTimeId() {
		return pickUpTimeId;
	}
	public void setPickUpTimeId(int pickUpTimeId) {
		this.pickUpTimeId = pickUpTimeId;
	}
	public String getTimeSlot() {
		return timeSlot;
	}
	public void setTimeSlot(String timeSlot) {
		this.timeSlot = timeSlot;
	}
	public PickUpTimeSlot(int pickUpTimeId, String timeSlot) {
		super();
		this.pickUpTimeId = pickUpTimeId;
		this.timeSlot = timeSlot;
	}
	public PickUpTimeSlot(int pickUpTimeId) {
		super();
		this.pickUpTimeId = pickUpTimeId;
	}
	@Override
	public String toString() {
		return "PickUpTimeSlot [pickUpTimeId=" + pickUpTimeId + ", timeSlot=" + timeSlot + "]";
	}
	


	


}



