package com.dhakad.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Cart {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@Column(name = "price",nullable =false)
	private int price;
	

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "categoryId")
	private Category category;
	

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "clothId")
	private Cloth cloth;
	
	@Column(name = "quantity",nullable =false)
	private int quantity;
	
	@Column(name = "customerId",nullable =false)
	private String customerId;
	
	
	
	
	

	@Override
	public String toString() {
		return "Cart [id=" + id + ", price=" + price + ", category=" + category + ", cloth=" + cloth + ", quantity="
				+ quantity + ", customerId=" + customerId + "]";
	}

	public Cart(int id) {
		super();
		this.id = id;
	}

	public Cart() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Cart(int id, int price, Category category, Cloth cloth, int quantity, String customerId) {
		super();
		this.id = id;
		this.price = price;
		this.category = category;
		this.cloth = cloth;
		this.quantity = quantity;
		this.customerId = customerId;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public Cloth getCloth() {
		return cloth;
	}

	public void setCloth(Cloth cloth) {
		this.cloth = cloth;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	
	
	

	
	
	
	
	
}
