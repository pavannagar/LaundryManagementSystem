package com.dhakad.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "delivery")
public class DeliverTimeSlot {

	@Id
	@Column(name = "deliver_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int deliverTimeId;
	private String timeSlot;
	
	public int getDeliverTimeId() {
		return deliverTimeId;
	}
	public void setDeliverTimeId(int deliverTimeId) {
		this.deliverTimeId = deliverTimeId;
	}
	public String getTimeSlot() {
		return timeSlot;
	}
	public void setTimeSlot(String timeSlot) {
		this.timeSlot = timeSlot;
	}
	public DeliverTimeSlot() {
		super();
		// TODO Auto-generated constructor stub
	}
	public DeliverTimeSlot(int deliverTimeId, String timeSlot) {
		super();
		this.deliverTimeId = deliverTimeId;
		this.timeSlot = timeSlot;
	}
	public DeliverTimeSlot(int deliverTimeId) {
		super();
		this.deliverTimeId = deliverTimeId;
	}
	@Override
	public String toString() {
		return "DeliverTimeSlot [deliverTimeId=" + deliverTimeId + ", timeSlot=" + timeSlot + "]";
	}

	
	
	
	
	
}
