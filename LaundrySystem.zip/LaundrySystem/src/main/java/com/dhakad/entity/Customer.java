package com.dhakad.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "customer")
public class Customer {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int customerId;
	
	@NotBlank(message = "please provide valid name")
	private String name;
	
	@NotBlank(message = "This feild can not be empty")
	@Column(name = "email",nullable = false,unique = true)
	private String email;
	
	@NotBlank(message = "password can not be empty")
	private String password;
	
	@NotBlank(message = "This feild can not be empty")
	private String mobile1;
	
	@NotBlank(message = "This feild can not be empty")
	private String mobile2;
	
	@NotBlank(message = "This feild can not be empty")
	private String address;
	
	@NotBlank(message = "This feild can not be empty")
	private String state;
	
	@NotBlank(message = "This feild can not be empty")
	private String city;
	
	@NotBlank(message = "This feild can not be empty")
	private String pincode;
	
	@NotBlank(message = "This feild can not be empty")
	private String houseNumber;
	
	@NotBlank(message = "This feild can not be empty")
	private String street;
	
	private Boolean enable;
	
	private String role;
	
	@JsonIgnore
	@OneToMany(mappedBy = "customer",cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	private List<Order> order;
	
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public String getHouseNumber() {
		return houseNumber;
	}
	public void setHouseNumber(String houseNumber) {
		this.houseNumber = houseNumber;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	
	public String getMobile1() {
		return mobile1;
	}
	public void setMobile1(String mobile1) {
		this.mobile1 = mobile1;
	}
	public String getMobile2() {
		return mobile2;
	}
	public void setMobile2(String mobile2) {
		this.mobile2 = mobile2;
	}
	public Boolean getEnable() {
		return enable;
	}
	public void setEnable(Boolean enable) {
		this.enable = enable;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public List<Order> getOrder() {
		return order;
	}
	public void setOrder(List<Order> order) {
		this.order = order;
	}
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", name=" + name + ", email=" + email + ", password=" + password
				+ ", mobile1=" + mobile1 + ", mobile2=" + mobile2 + ", address=" + address + ", state=" + state
				+ ", city=" + city + ", pincode=" + pincode + ", houseNumber=" + houseNumber + ", street=" + street
				+ ", enable=" + enable + ", role=" + role + "]";
	}
	
	
	
	
	
	
	
}
