package com.dhakad.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "status")
public class Status {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int statusId;
	
	@Column(name = "status_value",nullable = false)
	private String statusValue;
	
	public int getStatusId() {
		return statusId;
	}
	public void setStatusId(int statusId) {
		this.statusId = statusId;
	}
	public String getStatusValue() {
		return statusValue;
	}
	public void setStatusValue(String statusValue) {
		this.statusValue = statusValue;
	}
	public Status() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Status(int statusId, String statusValue) {
		super();
		this.statusId = statusId;
		this.statusValue = statusValue;
	}
	public Status(int statusId) {
		super();
		this.statusId = statusId;
	}
	@Override
	public String toString() {
		return "Status [statusId=" + statusId + ", statusValue=" + statusValue + "]";
	}
 	
	
	
	
	
}
