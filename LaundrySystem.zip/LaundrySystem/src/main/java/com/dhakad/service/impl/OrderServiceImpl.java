package com.dhakad.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.dhakad.entity.Customer;
import com.dhakad.entity.Order;
import com.dhakad.entity.Status;
import com.dhakad.repository.OrderRepo;
import com.dhakad.service.OrderService;

@Service
public class OrderServiceImpl implements OrderService{

	@Autowired
	private OrderRepo orderRepo;

	@Override
	public Order addOrder(Order order) {
		// TODO Auto-generated method stub
		return orderRepo.save(order);
	}

	@Override
	public List<Order> getAllOrder() {
		// TODO Auto-generated method stub
		return (List<Order>) orderRepo.findAll();
	}

	@Override
	public Order getOrderById(int id) {
		// TODO Auto-generated method stub
		return orderRepo.findById(id).get();
	}

	@Override
	public void removeOrder(int id) {
		// TODO Auto-generated method stub
		 orderRepo.deleteById(id);
	}

	@Override
	public Order updateOrder(Order order_table, int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int changeStatus(int orderId, Status status) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Object[]> getOrderStatus(int orderId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Order> getOrderByCustomerId(Customer customer) {
		List<Order> myOrders=orderRepo.getOrderByCustomerId(customer);
		return myOrders;
	}

	

	@Override
	public Page<Order> findPaginated(int pageNo, int pageSize, String sortField, String sortDirection) {
		Sort sort = sortDirection.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortField).ascending() :
			Sort.by(sortField).descending();
		
		Pageable pageable = PageRequest.of(pageNo - 1, pageSize, sort);
		return orderRepo.findAll(pageable);
	}
	
	

}
