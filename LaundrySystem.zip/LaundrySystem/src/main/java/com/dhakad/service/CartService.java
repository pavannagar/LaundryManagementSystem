package com.dhakad.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.dhakad.entity.Cart;
@Service
public interface CartService {

	public Cart addCart(Cart cart);
	public Cart getCartById(int id);
	public List<Cart> getAllCarts();
	public void deleteCart(int id);
	public List<Cart> getAllCartsByUsername(String username);
}
