package com.dhakad.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dhakad.entity.Cart;
import com.dhakad.repository.CartRepo;
import com.dhakad.service.CartService;

@Service
public class CartServiceImpl implements CartService{

	@Autowired
	private CartRepo cartRepo;
	
	@Override
	public Cart addCart(Cart cart) {
		return cartRepo.save(cart);
	}

	@Override
	public Cart getCartById(int id) {
		return cartRepo.findById(id).get() ;
	}

	@Override
	public List<Cart> getAllCarts() {
	List<Cart> carts=(List<Cart>) cartRepo.findAll();
		return carts;
	}

	@Override
	public void deleteCart(int id) {
		cartRepo.deleteById(id);
		
	}

	@Override
	public List<Cart> getAllCartsByUsername(String username) {
		List<Cart> carts=cartRepo.getAllCartsByUsername(username);
		return carts;
	}

}
