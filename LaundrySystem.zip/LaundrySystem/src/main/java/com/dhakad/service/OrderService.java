package com.dhakad.service;

import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;

import com.dhakad.entity.Customer;
import com.dhakad.entity.Order;
import com.dhakad.entity.Status;

import java.util.List;
@Service
public interface OrderService {

	
	public Order addOrder(Order order);
	public List<Order> getAllOrder();
	public Order getOrderById(int id);
	public void removeOrder(int id);
	public Order updateOrder(Order order_table,int id);
	public int changeStatus(int orderId,Status status);
	public List<Object[]> getOrderStatus(int orderId);
	public List<Order> getOrderByCustomerId(Customer customer);
	public Page<Order> findPaginated(int pageNo, int pageSize, String sortField, String sortDirection);
	
}
