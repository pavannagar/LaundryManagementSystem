package com.dhakad;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LaundrySystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(LaundrySystemApplication.class, args);
	}

}
