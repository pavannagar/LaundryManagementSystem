package com.dhakad.controller;

import java.security.Principal;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dhakad.entity.Cart;
import com.dhakad.entity.Category;
import com.dhakad.entity.Cloth;
import com.dhakad.entity.Customer;
import com.dhakad.entity.Ratelist;
import com.dhakad.helper.RegistrationMessage;
import com.dhakad.repository.CartRepo;
import com.dhakad.service.CartService;
import com.dhakad.service.CategoryService;
import com.dhakad.service.ClothService;
import com.dhakad.service.CustomerService;
import com.dhakad.service.RatelistService;

@Controller
public class CartController {

	@Autowired
	private CartService cartService;
	
	@Autowired
	private CategoryService categoryService;
	@Autowired
	private ClothService clothService;
	@Autowired
	private CustomerService customerService;
	@Autowired
	private RatelistService ratelistService;
	@Autowired
	private CartRepo cartRepo;
	
	@RequestMapping("/admin/cart")
	@ResponseBody
	public String addCart(Principal principal) {
		Customer customer=customerService.getCustomerByUsername(principal.getName());
		String username=customer.getEmail();
		List<Cart> mycart=cartRepo.getAllCartsByUsername(username);
		
		return "success";
	}
	
	
	@RequestMapping("/admin/carts")
	@ResponseBody
	public String getAllCarts() {
		List<Cart> carts= cartService.getAllCarts();
		
		return "successfullu....";
	}
	
	// show cart
	@RequestMapping("/admin/showCart")
	public String showCart(@ModelAttribute("cart")Cart cart,Model model,HttpSession session,Principal principal) {
		
		Customer customer=customerService.getCustomerByUsername(principal.getName());
		String username=customer.getEmail();
		List<Cart> carts=cartRepo.getAllCartsByUsername(username);
	
		//List<Cart> carts= cartService.getAllCarts();
		model.addAttribute("carts", carts);
		int totalPrice=0;
		int deliveryCharge=45;
		for(Cart c: carts ) {
			totalPrice=totalPrice+ c.getPrice();
		}
		model.addAttribute("totalPrice", totalPrice);
		
		if(totalPrice>450) {
			deliveryCharge=0;
		}
		model.addAttribute("deliveryCharge", deliveryCharge);
		int totalAmount=totalPrice+deliveryCharge;
		model.addAttribute("totalAmount", totalAmount);
		//System.out.println("total price : "+totalPrice);
		List<Cloth> cloths=clothService.getAllCloth();
		List<Category> categories=categoryService.getAllCategory();
		model.addAttribute("categories", categories);
		model.addAttribute("cloths", cloths);
	
		
		
		
		
		return "cart.html";
	}
	
	
	//add cart 
	@RequestMapping("/admin/addCart")
	public String addItemInCart(@ModelAttribute("cart")Cart cart,Principal principal,HttpSession session) {
		
		//checking if user want to add item that not listed in ratelist
		if(!isClothAndCatCombinationExist(cart)) {
			session.setAttribute("message", new RegistrationMessage("We Don't "+cart.getCategory().getCategoryName()+" "+cart.getCloth().getClothName()+"", "alert-info"));			
			return "redirect:/admin/showCart";
		}
		//if user want to add same item again than
		if(isClothAndCatePresentInCart(cart,principal)) {
			session.setAttribute("message", new RegistrationMessage("You already have this item . If want to change quantity You can change it when you place uour order", "alert-info"));
			return "redirect:/admin/showCart";
		}
		else {
				Customer customer =customerService.getCustomerByUsername(principal.getName());
				cart.setCustomerId(customer.getEmail());
				//method for fetching price of combination of cloth and category
				int price=ratelistService.getPriceByClothAndCategory(cart.getCloth(), cart.getCategory());
				cart.setPrice(price*(cart.getQuantity()));
				cartService.addCart(cart);
		}
					
		return "redirect:/admin/showCart";
	}
	
	@RequestMapping("/admin/deleteCart/{id}")
	public String deleteById(@PathVariable("id") int id) {
		cartService.deleteCart(id);
		return "redirect:/admin/showCart";
	}
	
	
	// this method will check is item are already present in card or not
	public Boolean isClothAndCatePresentInCart(Cart cart,Principal principal) {
		//List<Cart> carts= cartService.getAllCarts();
		Customer customer=customerService.getCustomerByUsername(principal.getName());
		String username=customer.getEmail();
		List<Cart> carts=cartRepo.getAllCartsByUsername(username);

		
		for(Cart c : carts) {
			if(c.getCloth()==cart.getCloth() && c.getCategory()==cart.getCategory()) {
				return true;
			}
		}
		return false;
	}
	
	
	//this method will check that the cat and cloth combination will exist in ratelist or not
	public Boolean isClothAndCatCombinationExist(Cart cart) {
		List<Ratelist> ratelist=ratelistService.getAllRatelist();
		for(Ratelist r:ratelist) {
			if(r.getCategory()==cart.getCategory() && r.getCloth()==cart.getCloth()) {
				return true;
			}
		}
		
		return false;
	}
	
	
	
	
	
	
	
	
	
	
}
