package com.dhakad.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.dhakad.entity.Customer;
import com.dhakad.service.CustomerService;

@Controller
public class CustomerDashboardController {

	@Autowired
	private CustomerService customerService;
	
	@RequestMapping("/user")
	public String userPage(Model model,Principal principal) {
	
		Customer customer=customerService.getCustomerByUsername(principal.getName());
		
		//System.out.println("user : "+customer.toString());
		model.addAttribute("user", customer);
		return "user.html";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
