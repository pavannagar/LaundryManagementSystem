package com.dhakad.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.dhakad.entity.Category;
import com.dhakad.service.CategoryService;

@Controller
public class CategoryController {
	
	@Autowired
	private CategoryService categoryService;
	
	//show category form
	@RequestMapping("/admin/showCategory")
	public String shoeCategoryForm(Model model) {
		List<Category> categories=categoryService.getAllCategory();
		//System.out.println("categories....."+categories);
		model.addAttribute("categories", categories);
		
		return "categoryForm.html";
	}
	
	///add or update category
	@RequestMapping("/admin/addCategory")
	public String addCategory(@ModelAttribute("category")Category category,Model model ) {
		categoryService.addCategory(category);
		return "redirect:/admin/showCategory";
	}
	@RequestMapping("admin/updateCategory/{id}")
	public String updatecategory(@PathVariable("id")int id,Model model) {
		Category category=categoryService.findById(id);
		model.addAttribute("category", category);
		return "updateCategory.html";
	}
	
	@RequestMapping("admin/deleteCategory/{id}")
	public String deleteCategry(@PathVariable("id")int id) {
		categoryService.removeCategory(id);
		return "redirect:/admin/showCategory";
	}
	
	
}
