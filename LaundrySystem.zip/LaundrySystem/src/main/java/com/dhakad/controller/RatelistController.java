package com.dhakad.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dhakad.entity.Category;
import com.dhakad.entity.Cloth;
import com.dhakad.entity.Ratelist;
import com.dhakad.repository.RatelistRepo;
import com.dhakad.service.CategoryService;
import com.dhakad.service.ClothService;
import com.dhakad.service.RatelistService;

@Controller
public class RatelistController {

	@Autowired
	private CategoryService categoryService;
	@Autowired
	private ClothService clothService;
	@Autowired
	private RatelistService ratelistService;
	@Autowired
	private RatelistRepo ratelistRepo;
	
	
	@RequestMapping("/admin/showRatelist")
	public String showRatelist(@ModelAttribute("ratelist")Ratelist ratelist, Model model) {
		List<Cloth> cloths=clothService.getAllCloth();
		List<Category> categories=categoryService.getAllCategory();
		List<Ratelist> ratelists=ratelistService.getAllRatelist();
		//System.out.println("....."+ratelists);
		//List<Ratelist> r=(List<Ratelist>) ratelistRepo.findAll();
		model.addAttribute("categories", categories);
		model.addAttribute("cloths", cloths);
		model.addAttribute("ratelists", ratelists);
		return "ratelist.html";
	}
	@RequestMapping("/user/showRatelist")
	public String showURatelist(@ModelAttribute("ratelist")Ratelist ratelist, Model model) {
		List<Cloth> cloths=clothService.getAllCloth();
		List<Category> categories=categoryService.getAllCategory();
		List<Ratelist> ratelists=ratelistService.getAllRatelist();
		//System.out.println("....."+ratelists);
		//List<Ratelist> r=(List<Ratelist>) ratelistRepo.findAll();
		model.addAttribute("categories", categories);
		model.addAttribute("cloths", cloths);
		model.addAttribute("ratelists", ratelists);
		return "userRatelist.html";
	}
	
	@RequestMapping("/admin/addRatelist")
	public String addRatelist(@ModelAttribute("ratelist") Ratelist ratelist) {
	//System.out.println("ratelist : "+ratelist.toString());
	ratelistService.addRatelist(ratelist);
		return "redirect:/admin/showRatelist";
	}
	
	@RequestMapping("/admin/updateRatelist/{id}")
	public String showUpdateRatelistForm(@PathVariable("id")int id,Model model) {
		Ratelist ratelist=ratelistService.getById(id);
		model.addAttribute("ratelist", ratelist);
		return "updateRatelist.html";
	}
	
	@RequestMapping("/admin/updateRatelist")
	public String updateRatelist(@RequestParam("id")int id,@RequestParam("price")int price) {
		// System.out.println("id : "+id+" price "+price);
		ratelistRepo.updateRatelist(id, price);
		return "redirect:/admin/showRatelist";
	}
	
	@RequestMapping("/admin/deleteRatelist/{id}")
	public String deleteRatelist(@PathVariable("id")int id) {
		ratelistService.removeById(id);
		
		 return "redirect:/admin/showRatelist";
	}
	
	
	
	
	
	
	
	
	
	
	
}
