package com.dhakad.controller;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.dhakad.entity.Customer;
import com.dhakad.helper.RegistrationMessage;
import com.dhakad.service.CustomerService;

 

@Controller
public class CustomerController {
	@Autowired
	private CustomerService customerService;
	
	@Autowired
	private BCryptPasswordEncoder passwordEncoder;

	
	@PostMapping("/register")
	public ModelAndView doRegistration(@Valid @ModelAttribute("customer") Customer customer,BindingResult result, @RequestParam(value = "tac",defaultValue = "false")boolean tac,HttpSession session){
		System.out.println("inside controller");
		if(result.hasErrors()) {
			//System.out.println("inside error");
			ModelAndView mv=new ModelAndView("signup.html");
			mv.addObject("user", customer);
			return mv;
		}
		
		if(tac==false) {
			try {
				throw new Exception("you have not agreed terms and condition");
			}catch(Exception e) {
				e.printStackTrace();
				ModelAndView mv=new ModelAndView("signup.html");
				mv.addObject("user", customer);
				session.setAttribute("message", new RegistrationMessage("you have not agreed terms and condition !!", "alert-danger"));
				return mv;
			}
		
		}
		
		
		try{
				if(customerService.getCustomerByUsername(customer.getEmail())==null ) {
				
					//ModelAndView mv=new ModelAndView("login.html");
					// add role and enable saperately
					ModelAndView mv=new ModelAndView("signup.html");
					mv.addObject("user", customer);
					customer.setEnable(true);
					customer.setRole("user");
					
					//admin.setPassword(passwordEncoder.encode(admin.getPassword()));
					customer.setPassword(passwordEncoder.encode(customer.getPassword()));
					customerService.addCustomer(customer);
					//System.out.println(customer.toString());
					session.setAttribute("message", new RegistrationMessage("Registration Successfully Done !!", "alert-success"));
					return mv;
				}else {
					ModelAndView mv=new ModelAndView("signup.html");
					mv.addObject("user", customer);
					session.setAttribute("message", new RegistrationMessage("This Email already taken !! ", "alert-danger"));
					return mv;
					
				}
			
				
				
		}catch(Exception e) {
			e.printStackTrace();
			ModelAndView mv=new ModelAndView("signup.html");
			mv.addObject("customer", customer);
			session.setAttribute("message", new RegistrationMessage("Something went wrong !!", "alert-danger"));
			return mv;
		}
	
	}
	
	
	
	//show address form
	@RequestMapping("/admin/showAddressForm")
	public String showAddressForm() {
		return "addressForm.html";
	}
	
	
	
	
	
	
	
	
}
