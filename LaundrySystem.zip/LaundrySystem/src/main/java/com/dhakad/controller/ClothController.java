package com.dhakad.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.dhakad.entity.Cloth;
import com.dhakad.service.ClothService;

@Controller
public class ClothController {

	@Autowired
	private ClothService clothService;
	
	// add or update cloth 
	@PostMapping("/admin/addCloth")
	public String addCloth(@ModelAttribute("cloth") Cloth cloth,Model model) {
		//System.out.println("update cloth value before"+cloth.toString());
		clothService.addcloth(cloth);
		//System.out.println("update cloth value after "+cloth.toString());
		return "redirect:/admin/showClothForm";
	}
	
	//get th list of all cloths
	@GetMapping("/getCloth")
	public List<Cloth> getCloth(Cloth cloth) {
		return clothService.getAllCloth();
				
	}
	
	//url for showing update form
	@RequestMapping("/admin/updateClothForm/{id}")
	public String showUpdateClothForm(@PathVariable(value = "id")int id ,Model model) {
		Cloth cloth=clothService.getClothById(id);
		model.addAttribute("cloth", cloth);
		//System.out.println(cloth.toString());
		return "updateCloth.html";
	}

	// showing cloth form to add new cloth 
	@RequestMapping("/admin/showClothForm")
	public String showClothForm(Model model) {
		List<Cloth> cloths=clothService.getAllCloth();
		model.addAttribute("cloths", cloths);
		//System.out.print(cloths.toString());
		return "clothForm.html";
	}
	
	
	// delete cloth by id
	@RequestMapping("/admin/deleteCloth/{id}")
	public String deleteCloth(@PathVariable(value = "id")int id ,Model model) {
		//delete cloth
		clothService.removeById(id);
		

		 return "redirect:/admin/showClothForm";
	}
	
	
	
	
	
	
	
	
}
