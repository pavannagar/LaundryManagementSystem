package com.dhakad.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class TestSecurity {

	@RequestMapping("/mylogin")
	public String showLogin() {
		return "login.html";
	}
	
	
}
