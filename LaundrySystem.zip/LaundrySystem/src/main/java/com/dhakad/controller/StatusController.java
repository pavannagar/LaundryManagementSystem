package com.dhakad.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.dhakad.entity.Status;
import com.dhakad.service.StatusService;

@Controller
public class StatusController {

	@Autowired
	private StatusService statusService;
	
	
	//show status form
	@RequestMapping("/admin/showStatusForm")
	public String showStatusForm(Model model) {
		List<Status> statusList=statusService.getAllStatus();
		model.addAttribute("statusList", statusList);
		return "status.html";
	}
	
	//add status
	@RequestMapping("/admin/addStatus")
	public String addStatus(@ModelAttribute("status")Status status) {
		statusService.addStatus(status);
		return "redirect:/admin/showStatusForm";
	}
	
	//delete status
	@RequestMapping("/admin/deleteStatus/{id}")
	public String deleteStatus(@PathVariable("id")int id) {
		statusService.removeStatus(id);
		return "redirect:/admin/showStatusForm";
	}
	
	
	
	
	
	
	
}
