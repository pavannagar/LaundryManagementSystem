package com.dhakad.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.dhakad.entity.PickUpTimeSlot;
import com.dhakad.service.PickUpTimeSlotService;

@Controller
public class PickUpTimeSlotController {

	@Autowired
	private PickUpTimeSlotService pickUpTimeSlotService;
	
	
	
	//to show pickup time slot form
	@RequestMapping("/admin/showPickUpForm")
	public String showPickUpForm(Model model) {
		List<PickUpTimeSlot> pickUpTimeSlots=pickUpTimeSlotService.getAllPickUpTimeSlot();
		model.addAttribute("pickUpTime", pickUpTimeSlots);
		return "pickUpTime.html";
	}
	
	//add pickup Time slot
	@RequestMapping("/admin/addPickUpTime")
	public String addPickUpTimeSlot(@ModelAttribute("pickUpTimeSlot")PickUpTimeSlot pickUpTimeSlot) {
		pickUpTimeSlotService.addPickUpTimeSlot(pickUpTimeSlot);
		return "redirect:/admin/showPickUpForm";
	}
	
	//update pickup
	
	
	//delete pickup time slot
	@RequestMapping("/admin/deletePickUp/{id}")
	public String deletePickUpTimeSlot(@PathVariable("id")int id) {
		pickUpTimeSlotService.removePickUpTimeSlot(id);
		return "redirect:/admin/showPickUpForm";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
