package com.dhakad.controller;

import java.security.Principal;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dhakad.entity.Cart;
import com.dhakad.entity.Category;
import com.dhakad.entity.Cloth;
import com.dhakad.entity.Customer;
import com.dhakad.entity.DeliverTimeSlot;
import com.dhakad.entity.Order;
import com.dhakad.entity.OrderItem;
import com.dhakad.entity.PickUpTimeSlot;
import com.dhakad.entity.Ratelist;
import com.dhakad.entity.Status;
import com.dhakad.helper.RegistrationMessage;
import com.dhakad.repository.OrderRepo;
import com.dhakad.service.CartService;
import com.dhakad.service.CategoryService;
import com.dhakad.service.ClothService;
import com.dhakad.service.CustomerService;
import com.dhakad.service.DeliverTimeSlotService;
import com.dhakad.service.OrderService;
import com.dhakad.service.PickUpTimeSlotService;
import com.dhakad.service.RatelistService;
import com.dhakad.service.StatusService;

@Controller
public class OrderController {

	
	@Autowired
	private CartService cartService;
	
	@Autowired
	private CategoryService categoryService;
	@Autowired
	private ClothService clothService;
	@Autowired
	private CustomerService customerService;
	@Autowired
	private RatelistService ratelistService;
	@Autowired
	private PickUpTimeSlotService pickUpTimeSlotService;
	@Autowired
	private DeliverTimeSlotService deliverTimeSlotService;
	@Autowired
	private OrderService orderService;
	@Autowired
	private StatusService statusService;
	@Autowired
	private OrderRepo orderRepo;
	
	@RequestMapping("/admin/confirmOrder")
	public String showConfirmOrder(@ModelAttribute("cart")Cart cart,Model model,HttpSession session,Principal principle) {
		//fetching user details address
		Customer customer=customerService.getCustomerByUsername(principle.getName());
		String address=" "+customer.getAddress()+" "+customer.getStreet()+" "+customer.getCity()+" - "+customer.getPincode()+" ";
		String customerName=customer.getName();
		String mobile1=customer.getMobile1();
		String mobile2=customer.getMobile2();
		//add this to model
		model.addAttribute("address", address);
		model.addAttribute("mobile1", mobile1);
		model.addAttribute("mobile2", mobile2);
		model.addAttribute("customerName", customerName);
		
		
		List<Cart> carts= cartService.getAllCarts();
		model.addAttribute("carts", carts);
		int totalPrice=0;
		int deliveryCharge=45;
		for(Cart c: carts ) {
			totalPrice=totalPrice+ c.getPrice();
		}
		model.addAttribute("totalPrice", totalPrice);
		
		if(totalPrice>450) {
			deliveryCharge=0;
		}
		model.addAttribute("deliveryCharge", deliveryCharge);
		int totalAmount=totalPrice+deliveryCharge;
		model.addAttribute("totalAmount", totalAmount);
		//System.out.println("total price : "+totalPrice);
		List<Cloth> cloths=clothService.getAllCloth();
		List<Category> categories=categoryService.getAllCategory();
		model.addAttribute("categories", categories);
		model.addAttribute("cloths", cloths);
	//list of pickup and deliver time slot
		List<PickUpTimeSlot> p=pickUpTimeSlotService.getAllPickUpTimeSlot();
		List<DeliverTimeSlot> d=deliverTimeSlotService.getAllDeliverTimeSlot();
		model.addAttribute("pickupTimes", p);
		model.addAttribute("deliveryTimes", d);
		
		return "confirmOrder.html";
	}

	
	
	@RequestMapping("/admin/order")
	public String addOrder(@ModelAttribute("order") Order order,Model model) {
		//model.addAttribute("order", order);
		//System.out.println("-----------------------------------------------------------------------");
		//System.out.println("order : "+order.toString());
		List<OrderItem> orderItems=order.getOrderItem();
		
		//System.out.println("-----------------------------------------------------------------------");
		//orderService.addOrder(order);
		
		return"redirect:/admin/confirmOrder";
	}

	// from now alll operation are user
	
	//add order
	@RequestMapping("/user/order")
	public String addUserOrder(@ModelAttribute("order") Order order,Model model,Principal principle) {
		//model.addAttribute("order", order);
		/*
		 * System.out.println(
		 * "-----------------------------------------------------------------------");
		 * System.out.println("order : "+order.toString()); List<OrderItem>
		 * orderItems=order.getOrderItem(); for(OrderItem o:orderItems) {
		 * System.out.println("order : "+o.getClothName()); }
		 */	
		//System.out.println("-----------------------------------------------------------------------");
		Customer customer=customerService.getCustomerByUsername(principle.getName());
		Status status=statusService.getStatusById(87);
		//System.out.print(status.getStatusValue());
		order.setCustomer(customer);
		order.setStatus(status);
		orderService.addOrder(order);
		
		return"redirect:/user/myOrder";
	}

	//confirm order
	@RequestMapping("/user/confirmOrder")
	public String showUserConfirmOrder(@ModelAttribute("cart")Cart cart,Model model,HttpSession session,Principal principle) {
		//fetching user details address
		Customer customer=customerService.getCustomerByUsername(principle.getName());
		String address=" "+customer.getAddress()+" "+customer.getStreet()+" "+customer.getCity()+" - "+customer.getPincode()+" ";
		String customerName=customer.getName();
		String mobile1=customer.getMobile1();
		String mobile2=customer.getMobile2();
		//add this to model
		model.addAttribute("address", address);
		model.addAttribute("mobile1", mobile1);
		model.addAttribute("mobile2", mobile2);
		model.addAttribute("customerName", customerName);
		
		
		
		String username=customer.getEmail();
		List<Cart> carts=cartService.getAllCartsByUsername(username);
		//List<Cart> carts= cartService.getAllCarts();
		model.addAttribute("carts", carts);
		int totalPrice=0;
		int deliveryCharge=45;
		for(Cart c: carts ) {
			totalPrice=totalPrice+ c.getPrice();
		}
		model.addAttribute("totalPrice", totalPrice);
		
		if(totalPrice>450) {
			deliveryCharge=0;
		}
		model.addAttribute("deliveryCharge", deliveryCharge);
		int totalAmount=totalPrice+deliveryCharge;
		model.addAttribute("totalAmount", totalAmount);
		//System.out.println("total price : "+totalPrice);
		List<Cloth> cloths=clothService.getAllCloth();
		List<Category> categories=categoryService.getAllCategory();
		model.addAttribute("categories", categories);
		model.addAttribute("cloths", cloths);
	//list of pickup and deliver time slot
		List<PickUpTimeSlot> p=pickUpTimeSlotService.getAllPickUpTimeSlot();
		List<DeliverTimeSlot> d=deliverTimeSlotService.getAllDeliverTimeSlot();
		model.addAttribute("pickupTimes", p);
		model.addAttribute("deliveryTimes", d);
		
		return "confirmUserOrder.html";
	}

		@RequestMapping("/user/myOrder")
		public String showMyOrder(Model model,Principal principal) {
			Customer customer=customerService.getCustomerByUsername(principal.getName());
			
			List<Order> orders=orderService.getOrderByCustomerId(customer);
			
		    model.addAttribute("allorder", orders);
			//System.out.println("my order : "+o);
			return "myOrder.html";
		}

		@RequestMapping("/page/{pageNo}")
		public String findPaginated(@PathVariable (value = "pageNo") int pageNo, 
				@RequestParam("sortField") String sortField,
				@RequestParam("sortDir") String sortDir,
				Model model) {
			int pageSize = 3;
			
			Page<Order> page = orderService.findPaginated(pageNo, pageSize, sortField, sortDir);
			List<Order> listorder = page.getContent();
			
			model.addAttribute("currentPage", pageNo);
			model.addAttribute("totalPages", page.getTotalPages());
			model.addAttribute("totalItems", page.getTotalElements());
			
			model.addAttribute("sortField", sortField);
			model.addAttribute("sortDir", sortDir);
			model.addAttribute("reverseSortDir", sortDir.equals("asc") ? "desc" : "asc");
			
			model.addAttribute("listorder", listorder);
			return "showOrderToAdmin.html";
		}
		// display list of employees
		@RequestMapping("/admin/adminorder")
		public String viewHomePage(Model model) {
			return findPaginated(1, "orderId", "asc", model);	
		}
	
}
