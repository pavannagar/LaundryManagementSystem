package com.dhakad.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.dhakad.entity.DeliverTimeSlot;
import com.dhakad.repository.DeliverTimeSlotRepo;
import com.dhakad.service.DeliverTimeSlotService;

@Controller
public class DeliverTimeSlotController {

	@Autowired
	private DeliverTimeSlotService deliverTimeSlotService;
	
	//show deliver time slot
	@RequestMapping("/admin/showDeliveryForm")
	public String showDeliverTimeSlotForm(Model model) {
		List<DeliverTimeSlot> deliverTimeSlots=deliverTimeSlotService.getAllDeliverTimeSlot();
		model.addAttribute("deliverTimeSlot", deliverTimeSlots);
		return "deliveryTime.html";
	}
	
	
	//add delivery time
	@RequestMapping("/admin/addDeliverTimeSlot")
	public String addDeliverTimeSlot(@ModelAttribute("deliverTimeSlot")DeliverTimeSlot deliverTimeSlot) {
		deliverTimeSlotService.addDeliverTimeSlot(deliverTimeSlot);
		return "redirect:/admin/showDeliveryForm";
	}
	
	//delete delivery time
	@RequestMapping("/admin/deleteDeliverTime/{id}")
	public String deletePickUpTimeSlot(@PathVariable("id")int id) {
		deliverTimeSlotService.removeDeliverTimeSlot(id);
		return "redirect:/admin/showDeliveryForm";
	}
	
}
