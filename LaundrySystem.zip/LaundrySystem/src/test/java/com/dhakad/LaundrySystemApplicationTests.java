package com.dhakad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LaundrySystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
